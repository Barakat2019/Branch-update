<?php if(Session::has('success')): ?>
<div class="alert alert-success" style="position: relative;top: 0px;width: 381px;left:4px;right: 700px;margin:12px auto;text-align: center">
     <?php echo e(Session::get('success')); ?></div>
<?php endif; ?>
 <?php /**PATH C:\xampp\htdocs\Takhles\resources\views/admin/includes/alerts/success.blade.php ENDPATH**/ ?>