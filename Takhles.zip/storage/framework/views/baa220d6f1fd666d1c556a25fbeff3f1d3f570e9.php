<?php if(Session::has('success')): ?>
<div class="alert alert-success" style="position: relative;top: 99px;width: 362px;left: 0px;right: 700px;">
     <?php echo e(Session::get('success')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Takhles\resources\views\includes\alerts\success.blade.php ENDPATH**/ ?>