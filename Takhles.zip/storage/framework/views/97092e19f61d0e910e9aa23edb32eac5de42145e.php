<?php if(Session::has('error')): ?>
<div class="alert alert-danger" style="position: relative;top: 0px;width: 381px;left:4px;right: 700px;margin:12px auto;text-align: center"> <?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Takhles\resources\views/admin/includes/alerts/errors.blade.php ENDPATH**/ ?>