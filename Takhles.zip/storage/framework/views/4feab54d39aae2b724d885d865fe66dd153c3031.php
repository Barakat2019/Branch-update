<?php if(Session::has('error')): ?>
<div class="alert alert-danger" style="position: relative;left: 0px;right: 700px;top:78px"> <?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Takhles\resources\views\includes\alerts\errors.blade.php ENDPATH**/ ?>