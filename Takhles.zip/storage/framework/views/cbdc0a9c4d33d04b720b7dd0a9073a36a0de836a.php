
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.includes.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-0 ">
  
  <div class="table-responsive">
    <table class="table table-hover table-striped">

      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Website</th>
          <th scope="col">Location</th>
          <th scope="col">Status</th>
          <th scope="col">Created_at</th>
          <th scope="col">Updated_at</th>
          <th scope="col" style="text-align: center">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(isset($companies)): ?>
          <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($company->name); ?></td>
            <td><?php echo e($company->website); ?></td>
            <td><?php echo e($company->location); ?></td>
            <td><?php echo e($company->getActive()); ?></td>
            <td><?php echo e($company->created_at); ?></td>
            <td><?php echo e($company->updated_at); ?></td>
            
            <td class="col d-flex justify-content-center ">
            <form>
              <a class="btn btn-success ml-1 myButton" href="<?php echo e(route('company.edit',$company->id)); ?>">تعديل</a>  
            </form>
            
              <form action="<?php echo e(route('company.destroy',$company->id)); ?>" method="post">
                  <?php echo method_field('delete'); ?>
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger ml-1 myButton">حذف</button>
                </form>
                <form>
                  <button class="btn btn-info ml-1 myButton">
                  <a  class="ml-1 p-2" style="color: white" href="<?php echo e(route('company.status',$company->id)); ?>"><?php if($company->active==0): ?>تفعيل<?php else: ?> الغاء <?php endif; ?></a>
                </button>
                </form>
                <form>
                  <button class="btn btn-secondary ml-1 myButton">
                    <a  class="ml-1 p-2" style="color: white" href="<?php echo e(route('company.employee',$company->id)); ?>">الموظفين</a>
                  </button>
                </form>
                
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        <?php endif; ?>  
      </tbody>
      <?php echo e($companies->links()); ?>

    </table>
  </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Takhles\resources\views/admin/company/index.blade.php ENDPATH**/ ?>