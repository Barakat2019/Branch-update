<?php
return[
    'en'=>'in English',
    'ar'=>'in Arabic',
    'Added Company'=>'Added Company',
    'Location'=>'Location',
    'website'=>'website',
    'Name'=>'Name',
    'submit'=>'submit',
    'Vendor'=>'Vendor',
    'Add Vendor'=>'Add Vendor',
    'Employee'=>'Employee',
    'Add Employee'=>'Add Employee',
    'Clients'=>'Clients',
    'Add Client'=>'Add Client',
    'Shipments'=>'Shipments',
    'Add Shipment'=>'Add Shipment',
    'company created successfully'=>'company created successfully',
    'Edit Company'=>'Edit Company',
    'Company Name'=>'Company Name',
    'website'=>'website',
    'update'=>'update',
    'phone'=>'phone'

]
?>