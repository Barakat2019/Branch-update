<?php
return[
    'en'=>'باللغة الانجليزية',
    'ar'=>'باللغة العربية',
    'Added Company'=>'اضافة شركة',
    'Location'=>'العنوان',
    'website'=>'الموقع الألكتروني',
    'Name'=>'الاسم',
    'submit'=>'اضافة',
    'Vendor'=>'الشركات',
    'Add Vendor'=>'أضافة شركة',
    'Employee'=>'الموظفين',
    'Add Employee'=>'اضافة موظف',
    'Edit Employee'=>'تعديل موظف',
    'Clients'=>'العملاء',
    'Add Client'=>'أضافة عميل',
    'Shipments'=>'الشحنات',
    'Add Shipment'=>'أضافة شحنة',
    'company created successfully'=>'تم أضافة الشركة بنجاح',
    'Edit Company'=>'تعديل شركة',
    'Company Name'=>'اسم الشركة',
    'website'=>'الموقع الألكتروني',
    'update'=>'تحديث',
    'Close'=>'أغلاق',
    'Added Shipment'=>'أضافة شحنة',
    'phone'=>'رقم الهاتف',
    'age'=>'العمر',
    'email'=>'البريد الألكتروني',
    'Added Client'=>'أضافة عميل',
    'company'=>'الشركة',
    'shipment number'=>'رقم الشحنة',
    'user'=>'المستخدم',
    'Shipment Type'=>'نوع الشحنة',
    'Select company'=>'اختر شركة',
    'Select shipment type'=>'اختر نوع الشحنة',
    'Select user'=>'اختر مستخدم',
    'Employee Name'=>'اسم الموظف'



]
?>