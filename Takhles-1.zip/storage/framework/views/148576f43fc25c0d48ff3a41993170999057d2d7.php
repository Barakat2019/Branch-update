
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
 
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">

    <title>Edit Company</title>
</head>
<?php echo $__env->make('includes.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('includes.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="img js-fullheight" style="background-image:url(<?php echo e(asset('assets/img/pexels-tom-fisk-3057960.jpg')); ?>)">
    <form action="<?php echo e(route('company.update',$company->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <input type="hidden" name="id" value="<?php echo e($company->id); ?>">
        <div class="container col-md-5">
            <div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section" style="margin-top: 100px;
                    "><?php echo e(__('messages.Edit Company')); ?></h2>
				</div>
			</div>
            <div class="row">
                <div class="mb-3">
                    <label for="website" class="form-label"><?php echo e(__('messages.Company Name')); ?>-<?php echo e(__('messages.'.$company->translation_lang)); ?></label>
                     <input type="text"  value="<?php echo e($company->name); ?>" class="form-control" id="name" name="company[0][name]" placeholder="Enter company name">
                </div>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="alert alert-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
                <div class="col-md-6 hidden" style="display: none !important">
                    <label>اختصار اللغة-<?php echo e(__('messages.'.$company->translation_lang)); ?></label>
                    <input type="text" id="translation_lang"   name="company[0][translation_lang]" class="form-control" value="<?php echo e($company->translation_lang); ?>">

                    <?php $__errorArgs = ['company.$index.translation_lang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger">هذا الحقل مطلوب</span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
         
            <div class="row">
                <div class="mb-3">
                    <label for="location" class="form-label"> <?php echo e(__('messages.Location')); ?>--<?php echo e(__('messages.'.$company->translation_lang)); ?></label>
                    <input type="text" value="<?php echo e($company->location); ?>" class="form-control" name="company[0][location]" id="location" placeholder="enter the address" rows="3">
                  </div>
                 <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="alert alert-danger"><?php echo e($message); ?></span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           
            <div class="row">
                <div class="mb-3">
                    <label for="website" class="form-label"> <?php echo e(__('messages.website')); ?></label>
                    <input type="text" value="<?php echo e($company->website); ?>" class="form-control" id="website" name="website" placeholder="Like name.com or net">
                </div>
                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="alert alert-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
    
           
            <div class="row">
                <button class="form-control btn btn-primary submit px-3" type="submit"><?php echo e(__('messages.update')); ?></button>

                

            </div>
        </div>
        </div>
    </form>
    
    <button type="button" class="btn btn-primary mt-2" data-toggle="modal" data-target="#exampleModal">
        تحديث الى لغة انجليزي
      </button>

      <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 style="margin-left: 150px;" class="modal-title" id="exampleModalLabel">تعديل شركة بالانجليزي</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <?php if(isset($company->trans_company)): ?>
                <?php $__currentLoopData = $company->trans_company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form class="form" action="<?php echo e(route('company.update',$translation->id)); ?>"
                    enctype="multipart/form-data" method="POST">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                            <!-- This field for return id when update method in validation  required_without:id -->
                            <input type="hidden" name="id" value="<?php echo e($translation->id); ?>"/>
                            <div class="row">
                                <div class="form-group">
                                        <div class="col-md-6">
                                            
                                            <label>اسم الشركة-<?php echo e(__('messages.'.$translation->translation_lang)); ?></label>
                                            <input type="text" id="name" name="company[0][name]" class="form-control input-edit" value="<?php echo e($translation->name); ?>">
                                            <?php $__errorArgs = ['company.0.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>
                            </div>
                            <div class="col-md-6 hidden" style="display: none !important">
                                <label>اختصار اللغة-<?php echo e(__('messages.'.$translation->translation_lang)); ?></label>
                                <input type="text" id="translation_lang"   name="company[0][translation_lang]" class="form-control" value="<?php echo e($translation->translation_lang); ?>">

                                <?php $__errorArgs = ['company.0.translation_lang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger">هذا الحقل مطلوب</span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row">
                                <div class="form-group">
                                        <div class="col-md-6">
                                            
                                            <label>العنوان-<?php echo e(__('messages.'.$translation->translation_lang)); ?></label>
                                            <input type="text" id="name" name="company[0][location]" class="form-control input-edit" value="<?php echo e($translation->location); ?>">
                                            <?php $__errorArgs = ['company.0.location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                </div>
                            </div>
                            <div class="row d-none">
                                <div class="mb-3">
                                    <label for="website" class="form-label"> <?php echo e(__('messages.website')); ?></label>
                                    <input type="text" value="<?php echo e($company->website); ?>" class="form-control" id="website" name="website" placeholder="Like name.com or net">
                                </div>
                                <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="alert alert-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                             
               
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php endif; ?>
       
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('messages.Close')); ?></button>
          <button type="submit" class="btn btn-primary"><?php echo e(__('messages.update')); ?></button>
        </div>
    </form>
      </div>
    </div>
</div>
     
	<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
	</body>
</html>

<?php /**PATH C:\xampp\htdocs\Takhles\resources\views\admin\company\edit.blade.php ENDPATH**/ ?>