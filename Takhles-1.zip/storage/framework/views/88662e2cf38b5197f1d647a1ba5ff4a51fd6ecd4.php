
<?php echo $__env->make('admin.includes.alerts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.includes.alerts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
  .table-bordered td, .table-bordered th
  {
    border: 0px solid #dee2e6 !important;
  }
  *, ::after, ::before {
    box-sizing: unset !important;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container mt-0 " style="padding: 7rem!important; ">
  
  <div class="table-responsive">
    <table class="table table-hover table-striped">

      <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Phone</th>
          <th scope="col">Email</th>
          <th scope="col">Company</th>
          <th scope="col">Status</th>
          <th scope="col" style="text-align: center">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(isset($employees)): ?>
          <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($employee->name); ?></td>
            <td><?php echo e($employee->phone); ?></td>
            <td><?php echo e($employee->email); ?></td>
            <td><?php echo e($employee->company->name); ?></td>
            <td><?php echo e($employee->active==1?'مفعل':'غير مفعل'); ?></td>
            <td class="col d-flex justify-content-center ">
            <form>
              <a class="btn btn-success ml-1 myButton" href="<?php echo e(route('employee.edit',$employee->id)); ?>">تعديل</a>  
            </form>
            
              <form action="<?php echo e(route('employee.destroy',$employee->id)); ?>" method="post">
                  <?php echo method_field('delete'); ?>
                  <?php echo csrf_field(); ?>
                  <button class="btn btn-danger ml-1 myButton">حذف</button>
                </form>
                <form>
                  <button class="btn btn-info ml-1 myButton">
                  <a  class="ml-1 p-2" style="color: white" href=""><?php if($employee->active==0): ?>تفعيل<?php else: ?> الغاء <?php endif; ?></a>
                </button>
                </form>
               
                
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        <?php endif; ?>  
      </tbody>
      <?php echo e($employees->links()); ?>

    </table>
  </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Takhles\resources\views/admin/employee/index.blade.php ENDPATH**/ ?>