<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Booking Form HTML Template</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap337.min.css')); ?>" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/employee.css')); ?>" />

</head>

<body>
	<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="booking-form">
						<div class="form-header">
							<h1><?php echo e(__('messages.Added Company')); ?></h1>
						</div>
						<form action="<?php echo e(route('company.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
							<?php if(get_languages()->count()>0): ?>
							<?php $__currentLoopData = get_languages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<span class="form-label"><?php echo e(__('messages.Name')); ?>-<?php echo e(__('messages.'.$lang->abbr)); ?></span>
											<input class="form-control" id="name" name="company[<?php echo e($index); ?>][name]" type="text" placeholder="Enter company name">
										</div>
										<?php $__errorArgs = ['company.$index.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="alert alert-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									<div class="col-md-6 hidden">
										<label>اختصار اللغة-<?php echo e(__('messages.'.$lang->abbr)); ?></label>
										<input type="text" id="translation_lang"   name="company[<?php echo e($index); ?>][translation_lang]" class="form-control" value="<?php echo e($lang->abbr); ?>">
		
										<?php $__errorArgs = ['company.$index.translation_lang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="text-danger">هذا الحقل مطلوب</span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									<div class="col-sm-6">
									<span class="form-label"><?php echo e(__('messages.Location')); ?>-<?php echo e(__('messages.'.$lang->abbr)); ?></span>
									<input class="form-control" name="company[<?php echo e($index); ?>][location]" id="location" placeholder="enter the address">
									<?php $__errorArgs = ['company.$index.location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="alert alert-danger"><?php echo e($message); ?></span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								<div class="row">

								
										<div class="form-group">
											<div class="col-sm-6">
												<div class="form-group">
													<span class="form-label"><?php echo e(__('messages.website')); ?></span>
													<input class="form-control" type="text" name="website" placeholder="Like name.com or net">
												</div>
												<?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="alert alert-danger"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
											
										</div>
								</div>

								
                                    <div class="form-btn">
                                        <button class="submit-btn"><?php echo e(__('messages.submit')); ?></button>
                                    </div>
                               
                                
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html> <?php /**PATH C:\xampp\htdocs\Takhles\resources\views\admin\company\create.blade.php ENDPATH**/ ?>