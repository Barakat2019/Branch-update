
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Booking Form HTML Template</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.0.8/css/fileinput.min.css" integrity="sha512-XHMymTWTeqMm/7VZghZ2qYTdoJyQxdsauxI4dTaBLJa8d1yKC/wxUXh6lB41Mqj88cPKdr1cn10SCemyLcK76A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<!-- Custom stlylesheet -->
	

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.5.0/themes/explorer-fa4/theme.min.css" integrity="sha512-eU/smVokNEm1qFFtPT5wuyr60YrKRxItg4J2zeHs+xqxYsBVMcWOGCLXghHMjrFHmQnjC7R/B26jr/IDkhDPWg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	

	<style>
		.main-section
		{
			padding: 20px;
			margin-top: 200px;
			background:#fff;
			box-shadow: 0 0 20px #c1c1c1;
		}
	</style>
</head>

<body>
	
	<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="booking-form">
						<div class="form-header">
							<h1><?php echo e(__('messages.Added Shipment')); ?></h1>
						</div>
						<form method="POST" enctype="multipart/form-data" action="<?php echo e(route('shipments.store')); ?>">
							<?php echo csrf_field(); ?>
							 
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<span class="form-label">Name</span>
										<input class="form-control" type="text" name="name" placeholder="Enter your name">
											
									</div>
								</div>
										
							</div>

							<div class="container">
								<div class="row">
									<div style="margin-top: 0px " class="col-lg-12 col-sm-12 col-11 main-section">
										<h1 class="text-center text-danger">Upload Image</h1>
										<div class="form-group">
											<input type="file" multiple name="images[]" class="file" data-overwrite-initial="false" id="file-1" data-mint file-count="2">
										</div>

									</div>
								</div>
							</div>
                   
                            
							<div class="form-btn">
								<button class="submit-btn">Submit</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-fileinput/5.5.0/js/fileinput.min.js" integrity="sha512-C9i+UD9eIMt4Ufev7lkMzz1r7OV8hbAoklKepJW0X6nwu8+ZNV9lXceWAx7pU1RmksTb1VmaLDaopCsJFWSsKQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
	<script type="text/javascript">
		$("#file-1").fileinput({
			theme:'fa',
			uploadUrl:'admin/shipments',
			uploadExtraData:function()
			{
				return {
					_token:$("$input[name='_token']").val();
				}
			},
			allowedFileExtensions:['jpg','png','gif'],
			overwriteInitial:false,
			maxFileSize:2000,
			maxFileNum:8,
			slugCallBack:function(filename)
			{
				return filename.replace('(','_').replace(']','_');
			}
		});
	</script>
</body> 

</html>
<?php /**PATH C:\xampp\htdocs\Takhles\resources\views\shipments\create.blade.php ENDPATH**/ ?>