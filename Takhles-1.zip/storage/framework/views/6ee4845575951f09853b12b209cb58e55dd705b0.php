<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Booking Form HTML Template</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap337.min.css')); ?>" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/employee.css')); ?>" />

</head>

<body>
	<div id="booking" class="section">
		<div class="section-center">
			<div class="container">
				<div class="row">
					<div class="booking-form">
						<div class="form-header">
							<h1><?php echo e(__('messages.Added Client')); ?></h1>
						</div>
						<form action="<?php echo e(route('clients.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
							 
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<span class="form-label"><?php echo e(__('messages.Name')); ?></span>
											<input class="form-control" id="name" name="name" type="text" placeholder="Enter company name">
										</div>
										<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="alert alert-danger"><?php echo e($message); ?></span>
										<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
									
									<div class="col-sm-6">
									<span class="form-label"><?php echo e(__('messages.Location')); ?></span>
									<input class="form-control" name="location" id="location" placeholder="enter the address">
									<?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
										<span class="alert alert-danger"><?php echo e($message); ?></span>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
									</div>
								</div>
								 
								<div class="row">

								
										<div class="form-group">
											<div class="col-sm-6">
												<div class="form-group">
													<span class="form-label"><?php echo e(__('messages.phone')); ?></span>
													<input class="form-control" type="text" name="phone" placeholder="Like name.com or net">
												</div>
												<?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="alert alert-danger"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>	
										</div>
                                        <div class="form-group">
											<div class="col-sm-6">
												<div class="form-group">
													<span class="form-label"><?php echo e(__('messages.email')); ?></span>
													<input class="form-control" type="text" name="email" placeholder="Like name.com or net">
												</div>
												<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
													<span class="alert alert-danger"><?php echo e($message); ?></span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
											</div>
											
										</div>
								</div>
                               

								<div class="row">

                                
                                    <div class="form-group">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <span class="form-label"><?php echo e(__('messages.age')); ?></span>
                                                <input class="form-control" type="text" name="age" placeholder="Like name.com or net">
                                            </div>
                                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="alert alert-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>	
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <span class="form-label"><?php echo e(__('messages.company')); ?></span>
                                                <select name="company_id" class="form-control">
                                                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp=>$index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($index); ?>"><?php echo e($comp); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>			
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="alert alert-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>	
                                    </div>

                                </div>

								
                                    <div class="form-btn">
                                        <button class="submit-btn"><?php echo e(__('messages.submit')); ?></button>
                                    </div>
                               
                                
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html> <?php /**PATH C:\xampp\htdocs\Takhles\resources\views\admin\client\create.blade.php ENDPATH**/ ?>