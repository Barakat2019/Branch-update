<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{ asset('assets/admin/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/admin/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/admin/css/admin-cards.css') }}">

<nav id="sidebar">
        <div class="p-4 pt-5">
          <a href="#" class="img logo rounded-circle mb-5" style="background-image:  url('assets/admin/images/logo.jpg') "></a>
    <ul class="list-unstyled components mb-5">
      <li class="active">
        <a href="#shipments" data-toggle="collapse" aria-expanded="false" data-target="#shipments" class="dropdown-toggle">{{ __('messages.Shipments') }}</a>
        <ul class="collapse list-unstyled sub-menu" id="shipments">
        <li>
            <a href="{{ route('shipments.index') }}">{{ __('messages.Shipments') }}</a>
            <a href="{{ route('shipments.create') }}">{{ __('messages.Add Shipment') }}</a>
        </li>
        </ul>
      </li>
    
      <li>
        <a href="#vendors" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">{{ __('messages.Vendor') }}</a>
        <ul class="collapse list-unstyled sub-menu" id="vendors">
        <li>
            <a href="{{ route('company.index') }}">{{ __('messages.Vendor') }}</a>
            <a href="{{ route('company.create') }}">{{ __('messages.Add Vendor') }}</a>
        </li>
        </ul>
      </li>
      
      <li>
        <a href="#Employee" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">{{ __('messages.Employee') }}</a>
        <ul class="collapse list-unstyled" id="Employee">
          <li>
              <a href="{{ route('employee.index') }}">{{ __('messages.Employee') }}</a>
              <a href="{{ route('employee.create') }}">{{ __('messages.Add Employee') }}</a>
          </li>
        </ul>
      </li>


      <li>
        <a href="#client" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">{{ __('messages.Clients') }}</a>
        <ul class="collapse list-unstyled" id="client">
        <li>
            <a href="#">{{ __('messages.Clients') }}</a>
            <a href="{{ route('clients.create') }}">{{ __('messages.Add Client') }}</a>
        </li>
        </ul>
      </li>


      <li>
          <a href="#">About</a>
      </li>
      <li>
      <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Pages</a>
      <ul class="collapse list-unstyled" id="pageSubmenu">
        <li>
            <a href="#">Page 1</a>
        </li>
        <li>
            <a href="#">Page 2</a>
        </li>
        <li>
            <a href="#">Page 3</a>
        </li>
      </ul>
      </li>
      <li>
      <a href="#">Portfolio</a>
      </li>
      <li>
        <a  href="{{ route('user.logout') }}"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </li>
    </ul>

    <div class="footer">
      
    </div>

    </div>
</nav>

<script src="{{ asset('assets/admin/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/admin/js/main.js') }}"></script>

